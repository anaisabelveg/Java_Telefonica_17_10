package com.telefonica;

import com.telefonica.models.Triangulo;

public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangulo triangulo = new Triangulo(5, 3, 20, 10);
		System.out.println("Area: " + triangulo.calcularArea());

	}

}
