module Ejemplo10_Clases_Abstractas {
}