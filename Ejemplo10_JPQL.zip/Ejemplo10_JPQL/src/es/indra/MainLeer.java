package es.indra;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

public class MainLeer {

	public static void main(String[] args) {
		// Crear el EntityManagerFactory sobre la unidad de persistencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU2");

		// Crear el EntityManager
		EntityManager em = emf.createEntityManager();
		
		// 1.- Buscar por PK
		int pk = 1;
		Cliente cliente = em.find(Cliente.class, pk);
		System.out.println(cliente);
		System.out.println("-----------------------------------");
		
		
		// 2.- Lectura JPQL
		Query query = em.createQuery("select c from Cliente c where c.nombre = :nom");
		query.setParameter("nom", "Juan");
		List<Cliente> juanes = query.getResultList();
		System.out.println(juanes);
		System.out.println("-----------------------------------");
		
		
		// 3.- Lectura por NamedQuery
		Query queryTodos = em.createNamedQuery("todos");
		List<Object[]> todos= queryTodos.getResultList();
		for (Object[] datos : todos) {
			System.out.println(Arrays.toString(datos));
		}
		System.out.println("-----------------------------------");
		
		// 4.- Crear queries nativas
		Query sql = em.createNativeQuery("select * from Ejemplo1_Clientes");
		List<Object[]> resultado = sql.getResultList();
		for (Object[] datos : resultado) {
			System.out.println(Arrays.toString(datos));
		}
		
		// 5.- Query a traves de un procedimiento almacenado
		StoredProcedureQuery proc = em.createNamedStoredProcedureQuery("nombre del procedimiento almacenado");
		proc.getResultList();
		
		
		
		em.close();

	}

}
