package es.indra;

public enum TipoCliente {
	
	NACIONAL, INTERNACIONAL;

}
