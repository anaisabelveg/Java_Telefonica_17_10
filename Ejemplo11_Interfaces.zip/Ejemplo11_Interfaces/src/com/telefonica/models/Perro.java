package com.telefonica.models;

public class Perro extends Animal implements ProductoVenta{
	
	private String codigo;
	private double precio;
	private boolean vacunado;
	private char sexo;
	
	public Perro() {
		// TODO Auto-generated constructor stub
	}

	public Perro(String nombre, int edad, String codigo, double precio, boolean vacunado, char sexo) {
		super(nombre, edad);
		this.codigo = codigo;
		this.precio = precio;
		this.vacunado = vacunado;
		this.sexo = sexo;
	}

	@Override
	public void setPrecio(double precio) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setCodigo(String codigo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getPrecio() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getCodigo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toString() {
		return "Perro [codigo=" + codigo + ", precio=" + precio + ", vacunado=" + vacunado + ", sexo=" + sexo
				+ ", toString()=" + super.toString() + "]";
	}
	
	

}
