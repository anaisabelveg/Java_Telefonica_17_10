package com.telefonica;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		Set numeros = new HashSet();
		numeros.add(1);
		numeros.add("dos");
		numeros.add(new Integer(3));
		
		for (Object obj : numeros) {
			System.out.println(obj);
		}
		
		// Java 5 incluye Genericos
		Set<Integer> numeros2 = new HashSet<Integer>();
		numeros2.add(1);
		// numeros2.add("dos");  Error de compilacion
		numeros2.add(new Integer(3));
		
		for (Integer num : numeros2) {
			System.out.println(num);
		}
		
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		
		for (String nombre : nombres) {
			System.out.println(nombre.toUpperCase());
		}
		
		Map<String, Double> alumnos = new HashMap<String, Double>();
		alumnos.put("Juan", 6.3);
		alumnos.put("Maria", 7.1);
		alumnos.put("Pedro", 4.2);
		
	}

}
