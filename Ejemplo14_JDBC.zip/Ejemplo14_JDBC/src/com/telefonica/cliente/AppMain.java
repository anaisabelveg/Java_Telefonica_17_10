package com.telefonica.cliente;

import com.telefonica.models.Producto;
import com.telefonica.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
			
		ProductosDAO dao = new ProductosDAO();
		
		dao.alta(new Producto(5, "Proyector", 450));
		
		for (Producto producto : dao.consultarTodos()) {
			System.out.println(producto);
		}
		
		System.out.println(dao.buscarPorId(3));

	}

}
