package com.telefonica.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.telefonica.models.Producto;

// DAO -> Data Access Object
public class ProductosDAO {
	
	private Connection conexion;
	
	public void alta(Producto nuevo){
		
		try {
			abrirConexion();
			String sql = "insert into PRODUCTOS values (?,?,?)";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, nuevo.getId());
			pst.setString(2, nuevo.getDescripcion());
			pst.setDouble(3, nuevo.getPrecio());
			int registros =  pst.executeUpdate();
			if (registros == 1) {
				System.out.println("Producto insertado");
			}
			
		} catch (Exception e) {
			System.out.println("Error al insertar el producto " + nuevo);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}

	}
	
	public Producto buscarPorId(int id){
		Producto producto = null;
		
		try {
			abrirConexion();
			String sql = "select * from PRODUCTOS where ID=?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs =  pst.executeQuery();
			if (rs.next()) {
				producto = new Producto(rs.getInt("ID"), 
						rs.getString("DESCRIPCION"), 
						rs.getDouble("PRECIO"));
			}
			
		} catch (Exception e) {
			System.out.println("Error al buscar el producto con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return producto;
	}
	
	public List<Producto> consultarTodos(){
		List<Producto> lista = new ArrayList();
		
		try {
			abrirConexion();
			Statement stm = conexion.createStatement();
			ResultSet registros =  stm.executeQuery("select * from PRODUCTOS");
			while (registros.next()) {
				lista.add(new Producto(registros.getInt("ID"), 
						registros.getString("DESCRIPCION"), 
						registros.getDouble("PRECIO")));
			}
			
		} catch (Exception e) {
			System.out.println("Error al consultar todos los productos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}
	
	private void abrirConexion() {
		try {
			// Cargar el driver de la BBDD
			Class.forName("com.mysql.jdbc.Driver");
			
			// Abrimos la conexion
			conexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/TIENDA", "root", "");
		} catch(ClassNotFoundException ex) {
			System.out.println("Error al cargar el driver");
			ex.printStackTrace();
		} catch(SQLException ex) {
			System.out.println("Error al abrir la conexion");
			ex.printStackTrace();
		}
		
	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (Exception ex) {
			System.out.println("Error al cerrar la conexion");
			ex.printStackTrace();
		}
	}

}
