package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class AppMain {

	public static void main(String[] args) {
		// Crear el EntityManagerFactory sobre la unidad de persistencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager
		EntityManager em = emf.createEntityManager();
		
		// Obtener una tx
		EntityTransaction et = em.getTransaction();
		
		// Crear las instancias de direccion
		Direccion dir1 = new Direccion("Avda.Elvas", 25 , 06511, "Badajoz");
		
		// Crear las instancias de cliente
		Cliente cli1 = new Cliente(1, "Juan", "B-12345678", 616111111, TipoCliente.INTERNACIONAL, 
				dir1, "Historico del cliente 1 ..... ");
		Cliente cli2 = new Cliente(2, "Pedro", "B-98765432", 616222222, TipoCliente.NACIONAL, 
				new Direccion("Castellana", 87, 28015,"Madrid"), "Historico del cliente 2 ..... ");
		Cliente cli3 = new Cliente(3, "Maria", "B-67087695", 616333333, TipoCliente.INTERNACIONAL, 
				new Direccion("P� Gracia", 54, 8016, "Barcelona"), "Historico del cliente 3 ..... ");
		
		try {
			et.begin();
			
			em.persist(cli1);
			em.persist(cli2);
			em.persist(cli3);
			
			et.commit();
			
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}

	}

}
