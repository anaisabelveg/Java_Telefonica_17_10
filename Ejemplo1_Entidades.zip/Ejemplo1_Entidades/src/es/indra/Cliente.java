package es.indra;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;

@Entity
@Table(name="Ejemplo1_Clientes")
@SecondaryTable(name="Ejemplo1_Historicos", 
                pkJoinColumns={@PrimaryKeyJoinColumn(name="id_cliente", referencedColumnName="id")}
)

//@SecondaryTables({
//	@SecondaryTable(name="Ejemplo1_Historicos", 
//            pkJoinColumns={@PrimaryKeyJoinColumn(name="id_cliente", referencedColumnName="id")}),
//
//	@SecondaryTable(name="Ejemplo1_Historicos", 
//    pkJoinColumns={@PrimaryKeyJoinColumn(name="id_cliente", referencedColumnName="id")})
//
//})
public class Cliente implements Serializable {

	@Id
	private int ID;
	
	@Column(name="nombreCli", length=100, nullable=false)
	private String nombre;
	
	private String cif;
	private long telefono;
	
	@Enumerated(EnumType.ORDINAL)
	private TipoCliente tipo;
	
	@Embedded
	private Direccion direccion;
	
	@Lob
	@Basic(fetch=FetchType.LAZY)
	@Column(table="Ejemplo1_Historicos")
	private String historico;
		
	public Cliente() {
		// TODO Auto-generated constructor stub
	}
	
	public Cliente(int iD, String nombre, String cif, long telefono, TipoCliente tipo, Direccion direccion,
			String historico) {
		super();
		ID = iD;
		this.nombre = nombre;
		this.cif = cif;
		this.telefono = telefono;
		this.tipo = tipo;
		this.direccion = direccion;
		this.historico = historico;
	}


	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public long getTelefono() {
		return telefono;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public TipoCliente getTipo() {
		return tipo;
	}

	public void setTipo(TipoCliente tipo) {
		this.tipo = tipo;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}
	
	

}
