package com.telefonica;

public class AppMain {

	// Marca el punto de entrada a la aplicacion
	public static void main(String[] args) {
		
		
		/*
		 * Ejemplo para mostrar los tipos primitivos
		 * */
		
		// Numericos enteros
		byte numByte = (byte)8;   	   // 8 bits
		short numShort = (short)250;   // 16 bits
		int numInt = 567876;           // 32 bits (defecto)
		long numLong = 56787654323L;   // 64 bits   sufijo L ó l 
		
		
		// Numericos reales
		float numFloat = 56.12F;        // 32 bits sufijo F ó f
		double numDouble = 6778.654;    // 64 bits  (defecto)
		
		
		// boolean: true y false
		boolean soltero = true;
		boolean incidencia = false;
		
		
		// Caracter: 'caracter'
		char letra = 'y';
		
		
		System.out.println("NumByte " + numByte );
		System.out.println("NumShort " + numShort );
		System.out.println("NumInt " + numInt );
		System.out.println("NumLong " + numLong );
		System.out.println("NumFloat " + numFloat );
		System.out.println("NumDouble " + numDouble );
		System.out.println("soltero " + soltero );
		System.out.println("letra " + letra );
		
		// String es una clase, no es un tipo primitivo
		// La clase se escribe primera letra mayusculas.
		// Las cadenas de texto van entre comillas dobles
		String nombre = "Anabel";
		System.out.println("nombre " + nombre );
		
		
	} // Fin de metodo

} // Fin de clase
