package com.telefonica;

public class Operadores {
	
	public static void main(String[] args) {
		// Operadores aritmeticos
		int num1 = 7;
		int num2 = 3;
		
		
		System.out.println("Suma " + (num1 + num2));
		System.out.println("Resta " + (num1 - num2));
		System.out.println("Multiplicacion " + (num1 * num2));
		System.out.println("Division " + (num1 / num2));
		System.out.println("Modulo " + (num1 % num2));
		
		
		// Operadores de comparacion
		boolean mayor = (num1 > num2);
		System.out.println("Es mayor el numero 1? " + mayor);
		System.out.println("Es menor el numero 1? " + (num1 < num2));
		System.out.println("Es mayor o igual el numero 1? " + (num1 >= num2));
		System.out.println("Es menor o igual el numero 1? " + (num1 <= num2));
		System.out.println("Es igual el numero 1 al numero 2? " + (num1 == num2));
		System.out.println("Son distintos el numero 1 al numero 2? " + (num1 != num2));
		
		
		// Operadores de asignacion
		num1 += 5;    // num1 = num1 + 5;
		num1 -= 5;    // num1 = num1 - 5;
		num1 *= 5;    // num1 = num1 * 5;
		num1 /= 5;    // num1 = num1 / 5;
		num1 %= 5;    // num1 = num1 % 5;
		
		
		// Incrementos y decrementos
		num2++;  // num2 += 1    num2 = num2 + 1
		num2--;  // num2 -= 1    num2 = num2 - 1
		
		int resultado = num2++;    // post-incremento  1º asigna, 2º incrementa
		resultado = ++num2;        // pre-incremento   1º incrementa, 2º asigna

	}

}
