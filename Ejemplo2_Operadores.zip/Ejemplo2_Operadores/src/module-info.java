module Ejemplo2_Operadores {
}