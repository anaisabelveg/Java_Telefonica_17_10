package com.telefonica;

import com.telefonica.models.Fecha;
import com.telefonica.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 17;
		fecha.mes = 10;
		fecha.anyo = 2022;
		
		fecha.mostrar();
		
		Fecha fechaErronea = new Fecha();
		fechaErronea.dia = -765567;
		fechaErronea.mes = 17655;
		fechaErronea.anyo = -467;
		
		fechaErronea.mostrar();
		
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(765567);
		fechaEncapsulada.setMes(17655);
		fechaEncapsulada.setAnyo(-467);
		
		fechaEncapsulada.mostrar();

	}

}
