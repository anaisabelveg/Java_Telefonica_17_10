module Ejemplo4_Encapsulacion {
}