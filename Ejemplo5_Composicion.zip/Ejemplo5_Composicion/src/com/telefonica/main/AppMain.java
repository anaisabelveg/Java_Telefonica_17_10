package com.telefonica.main;

import com.telefonica.models.*;

public class AppMain {

	public static void main(String[] args) {
		
	
		// Crear objetos o instancias de Empleado
		Empleado empleado =  new Empleado();
		empleado.numEmpleado = 1;
		empleado.nombre = "Juan";
		empleado.sueldo = 54000;
		empleado.direccion = new Direccion("Diagonal", 134, "Barcelona");
		
		empleado.mostrarDetalle();
		System.out.println(empleado.verNombre());
		empleado.cambiarSueldo(56000);
		empleado.mostrarDetalle();
		
		
		Direccion direccion = new Direccion("Mayor", 5, "Madrid");
		Empleado empleado2 = new Empleado(2, "Maria", 57000, direccion);
		empleado2.mostrarDetalle();

	}

}
