package com.telefonica.models;

public class Empleado {
	
	// propiedades, caracteristicas, atributos
	public int numEmpleado;
	public String nombre;
	public double sueldo;
	public Direccion direccion;
	
	public Empleado() {
		// TODO Auto-generated constructor stub
	}
	
	// Constructor completo
	public Empleado(int numEmpleado, String nombre, double sueldo, Direccion direccion) {
		super();
		this.numEmpleado = numEmpleado;  // this apunta a la propia instancia
		this.nombre = nombre;
		this.sueldo = sueldo;
		this.direccion = direccion;
	}


	// Metodos, funciones, acciones
	public void mostrarDetalle(){
		System.out.println("Numero: " + numEmpleado + " Nombre: " + nombre + 
				" Sueldo: " + sueldo + " Direccion: " + direccion.mostrar());
	}
	
	public String verNombre() {
		return nombre;
	}
	
	public void cambiarSueldo(double nuevo) {
		sueldo = nuevo;
	}

}
