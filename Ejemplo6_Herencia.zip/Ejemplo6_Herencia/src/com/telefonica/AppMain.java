package com.telefonica;

import com.telefonica.models.Empleado;
import com.telefonica.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// crear un objeto Empleado
		Empleado empleado1 = new Empleado("Juan", 37, 1, 45000);
		Empleado empleado2 = new Empleado("Juan", 37, 1, 45000);
		
		System.out.println(empleado1);
		
		// El operador == compara el contenido de las variables
		// en el caso de objetos, compara direcciones de memoria
		System.out.println("Son iguales? " + (empleado1 == empleado2));
		
		// Para comparar objetos utilizo equals
		System.out.println("Son iguales? " + (empleado1.equals(empleado2)));
		
		
		// Polimorfismo
		Object objeto = new Empleado("Juan", 37, 1, 45000);
		Persona persona = new Empleado("Juan", 37, 1, 45000);
		Empleado empleado = new Empleado("Juan", 37, 1, 45000);
		
		// Cambiar la visibilidad del objeto
		((Empleado)objeto).getNombre();
		((Persona)objeto).getNombre();
		
	}

}
