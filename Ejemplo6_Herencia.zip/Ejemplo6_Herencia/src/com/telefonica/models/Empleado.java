package com.telefonica.models;

import java.util.Objects;

public class Empleado extends Persona{
	
	private int numEmpleado;
	private double sueldo;
	
	// Constructor por defecto
	// El compilador en el momento de la compilacion comprueba si existe algun constructor
	// si no existe ninguno, añade el constructor por defecto
	public Empleado() {
		// implicitamente en todos los constructores la llamada es super()
		super();
	}
	
	public Empleado(String nombre, int edad, int numEmpleado, double sueldo) {
		// Invoca al constructor de la superclase - Persona
		super(nombre, edad);
		this.numEmpleado = numEmpleado;
		this.sueldo = sueldo;
	}
	
	@Override
	public String toString() {
		return super.toString() + " numEmpleado=" + numEmpleado + ", sueldo=" + sueldo;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(numEmpleado, sueldo);
		return result * super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		return super.equals(obj) &&
				numEmpleado == other.numEmpleado
				&& Double.doubleToLongBits(sueldo) == Double.doubleToLongBits(other.sueldo);
	}

	public int getNumEmpleado() {
		return numEmpleado;
	}

	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleado = numEmpleado;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}


}
