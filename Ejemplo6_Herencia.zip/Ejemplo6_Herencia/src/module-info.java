module Ejemplo6_Herencia {
}