package com.telefonica;

public class For {

	public static void main(String[] args) {
		
		// Mostrar los numeros del 1 al 10
		for(int i=1; i<=10; i++) {
			System.out.println(i);
		}
		
		// A partir de Java 5 for-each
		String [] nombres = {"Luis", "Juan", "Maria", "Laura"};
		for (String item : nombres) {
			System.out.println(item);
		}
		
		// Anidar bucles
		for(int tabla=1; tabla <= 10; tabla++) {
			System.out.println("----- Tabla del numero: " + tabla + " -----");
			
			for(int num=1; num<=10; num++) {
				System.out.println(tabla + "x" + num + "=" + (tabla*num));
			}
			System.out.println();
		}

	}

}
