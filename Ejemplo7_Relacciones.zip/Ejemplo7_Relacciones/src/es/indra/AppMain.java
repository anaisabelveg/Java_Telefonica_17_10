package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class AppMain {

	public static void main(String[] args) {
		// Crear el EntityManagerFactory sobre la unidad de persistencia
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// Crear el EntityManager
		EntityManager em = emf.createEntityManager();
		
		// Obtener una tx
		EntityTransaction et = em.getTransaction();
		
		// Crear nifs
		Nif n1 = new Nif(12345678, 'A');
		Nif n2 = new Nif(45587453, 'B');
		Nif n3 = new Nif(98245781, 'C');
		
		// Crear telefonos
		Telefono t1 = new Telefono(656111111);
		Telefono t2 = new Telefono(656222222);
		Telefono t3 = new Telefono(656333333);
		Telefono t4 = new Telefono(656444444);
		Telefono t5 = new Telefono(656555555);
		Telefono t6 = new Telefono(656666666);
		
		// Crear coches
		Coche c1 = new Coche("1111-HGG", "A3");
		Coche c2 = new Coche("2222-HGG", "A4");
		Coche c3 = new Coche("3333-HGG", "A5");
		Coche c4 = new Coche("4444-HGG", "A6");
		
		// Crear personas
		Persona p1 = new Persona("Juan", n1);
		Persona p2 = new Persona("Pedro", n2);
		Persona p3 = new Persona("Maria", n3);
		
		// Asignar telefonos
		p1.addTelefono(t1);
		p1.addTelefono(t2);
		p2.addTelefono(t3);
		
		p2.addTelefono(t4);
		p3.addTelefono(t5);
		p3.addTelefono(t6);
		
		// Asignar coches
		p1.addCoche(c1);
		p1.addCoche(c2);
		p1.addCoche(c3);
		
		p2.addCoche(c2);
		p2.addCoche(c3);
		p2.addCoche(c4);
		
		p3.addCoche(c1);
		p3.addCoche(c4);
		
		
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
			
			System.out.println(p1);
			System.out.println(p2);
			System.out.println(p3);
			
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}

	}

}
