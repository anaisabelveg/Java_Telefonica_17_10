package es.indra;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Coche
 *
 */
@Entity
@Table(name="Ejemplo7_Coche")
public class Coche implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="coche_id")
	private Long id;
	
	private String matricula;
	private String modelo;
	
	@ManyToMany(mappedBy="coches",
			cascade={CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH})
	private Set<Persona> propietarios = new HashSet<>();

	public Coche() {
		super();
	}

	public Coche(String matricula, String modelo) {
		super();
		this.matricula = matricula;
		this.modelo = modelo;
	}
	
	// Metodo de sincronizacion
	public void addPropietario(Persona persona){
		propietarios.add(persona);
		persona.getCoches().add(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Set<Persona> getPropietarios() {
		return propietarios;
	}

	public void setPropietarios(Set<Persona> propietarios) {
		this.propietarios = propietarios;
	}

	@Override
	public String toString() {
		return "Coche [matricula=" + matricula + ", modelo=" + modelo + "]";
	}
	
	
   
}
