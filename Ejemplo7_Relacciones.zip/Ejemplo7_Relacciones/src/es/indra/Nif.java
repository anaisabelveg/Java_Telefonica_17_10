package es.indra;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Nif
 *
 */
@Entity
@Table(name="Ejemplo7_Nifs")
public class Nif implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="nif_id")
	private Long id;
	
	private long numero;
	private char letra;
	
	@OneToOne(mappedBy="nif") //Es la propiedad nif de la entidad Persona. Debe ser igual
	private Persona persona;

	public Nif() {
		super();
	}

	public Nif(long numero, char letra) {
		super();
		this.numero = numero;
		this.letra = letra;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public char getLetra() {
		return letra;
	}

	public void setLetra(char letra) {
		this.letra = letra;
	}
	
	public Persona getPersona() {
		return persona;
	}
	
	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public String toString() {
		return "Nif [numero=" + numero + ", letra=" + letra + "]";
	}
	
	
   
}
