package es.indra;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Persona
 *
 */
@Entity
@Table(name="Ejemplo7_Personas")
public class Persona implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="persona_id")
	private Long id;
	

	private String nombre;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="id_nif", referencedColumnName="nif_id")
	private Nif nif;
	
	@OneToMany(mappedBy="persona", cascade=CascadeType.ALL)
	private Set<Telefono> telefonos = new HashSet<>();
	
	@ManyToMany(cascade={CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH})
	@JoinTable(name="Ejemplo7_personas_coches",
			   joinColumns=@JoinColumn(name="persona_id", referencedColumnName="persona_id"),
			   inverseJoinColumns=@JoinColumn(name="coche_id", referencedColumnName="coche_id"))
	private Set<Coche> coches = new HashSet<>();
	

	public Persona() {
		super();
	}
	
	public Persona(String nombre, Nif nif) {
		super();
		this.nombre = nombre;
		this.nif = nif;
	}
	
	// Metodo de sincronizacion se utiliza uno por cada atributo de tipo coleccion.
	public void addTelefono(Telefono telefono){
		telefonos.add(telefono);
		telefono.setPersona(this);
	}
	
	// Metodo de sincronizacion
	public void addCoche(Coche coche){
		coches.add(coche);
		coche.getPropietarios().add(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Nif getNif() {
		return nif;
	}

	public void setNif(Nif nif) {
		this.nif = nif;
	}

	public Set<Telefono> getTelefonos() {
		return telefonos;
	}

	public void setTelefonos(Set<Telefono> telefonos) {
		this.telefonos = telefonos;
	}

	public Set<Coche> getCoches() {
		return coches;
	}

	public void setCoches(Set<Coche> coches) {
		this.coches = coches;
	}

	@Override
	public String toString() {
		return "Persona [id=" + id + ", nombre=" + nombre + ", nif=" + nif + ", telefonos=" + telefonos + ", coches="
				+ coches + "]";
	}

}
