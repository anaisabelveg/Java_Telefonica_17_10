package com.telefonica;

public class Arrays {

	public static void main(String[] args) {
		// Declarar una variable de tipo array
		int numeros[];
        // String [] nombres;
		// char[] letras;
		
		// Crear el array
		numeros = new int[4];
		
		// Asignar valores al array
		numeros[0] = 6;
		numeros[1] = 9;
		numeros[2] = 4;
		numeros[3] = 1;
		
		// Todo en uno
		String [] nombres = {"Marta", "Juan", "Lola", "Antonio", "Luis"};
		
		char[] letras = new char[] {'a','e','i','o','u'};
		System.out.println(java.util.Arrays.toString(letras));
		
		for (char letra : letras) {
			System.out.println(letra);
		}
		
		// Los string no son mutables, no son modificados
		String cadena = "";
		for (String nombre : nombres) {
			cadena += nombre + " ";
		}
		System.out.println(cadena);
		
		// Es mejor utilizar StringBuilder
		StringBuilder cadenaBuild = new StringBuilder();
		for (String nombre : nombres) {
			cadenaBuild.append(nombre);
			cadenaBuild.append(" ");
		}
		System.out.println(cadenaBuild);
		

	}

}
