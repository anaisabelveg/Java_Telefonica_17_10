package com.telefonica;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class AppMain {

	public static void main(String[] args) {
		
		// LocalDate
		System.out.println(LocalDate.now());
		System.out.println(LocalDate.of(2023,5,28) );
		System.out.println(LocalDate.now().isBefore(LocalDate.of(2023,5,28)));
		System.out.println(LocalDate.now().isLeapYear());
		System.out.println(LocalDate.now().getDayOfWeek());
		System.out.println(LocalDate.now().plusMonths(1));
		//System.out.println(LocalDate.now().with(next("TUESDAY")));
		
		DateTimeFormatter miFormato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String hoy =  LocalDate.now().format(miFormato);
		System.out.println(hoy);
		
		// LocalTime
		System.out.println(LocalTime.now());
		System.out.println(LocalTime.now().plusHours(1).plusMinutes(15));
		System.out.println(LocalTime.now().truncatedTo(ChronoUnit.MINUTES));
		System.out.println(LocalTime.now().toSecondOfDay());
		System.out.println(LocalTime.now().isAfter(LocalTime.of(19,30)));
		System.out.println(LocalTime.now().until(LocalTime.of(19,30), ChronoUnit.MINUTES));
		
		// LocalDateTime
		System.out.println(LocalDateTime.of(2022,12,25,22,00,00,00));
		System.out.println(LocalDateTime.of(LocalDate.now(), LocalTime.now()));
		System.out.println(LocalDateTime.now().plusDays(4).plusHours(8));
		
	}

}
